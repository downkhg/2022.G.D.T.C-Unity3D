﻿using UnityEngine;

public class ScenePicker : MonoBehaviour
{
	[SerializeField]
	public string scenePath;
}