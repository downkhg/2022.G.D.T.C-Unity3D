﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GUIRankData : MonoBehaviour
{
    public Image m_cIcon;
    public Text m_cName;
    public Text m_cScore;

    public /*override*/ void Set(string img, string name, int score)
    {
        Sprite imgSprite = Resources.Load("Icon/"+img) as Sprite;
        m_cIcon.sprite = imgSprite;
        m_cName.text = name;
        m_cScore.text = string.Format("{0}",score);
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
