﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimateSprite : MonoBehaviour {
    public struct SAniFrame
    {
        public int nStart;
        public int nEnd;

        public SAniFrame(int start, int end)
        {
            nStart = start;
            nEnd = end;
        }
    }

    public List<Sprite> m_listAnimation = new List<Sprite>();
    public string m_strAniFrameInfo = ""; 
    public List<SAniFrame> m_listAniFrames = new List<SAniFrame>();
    public int m_nAniFPS = 60;

    protected float m_fTime = 0;
    protected int m_nCurFrame = 0;
    protected int m_nCurStatus = 0;
    protected SpriteRenderer m_cSpriteRender;

    public void Initialize()
    {
        m_cSpriteRender = GetComponent<SpriteRenderer>();
        LoadInfo(m_strAniFrameInfo);
    }

    // Use this for initialization
    //void Start () {
    private void Awake()
    {
        //순서상 문제가 생길수있으므로 사용하는곳에서 만들어주는것이 더욱 적절하다.
        //Initialize();
        Debug.Log(this + ".Awake()");
    }
	
	// Update is called once per frame
	void Update () {
        UpdateFrame(Time.deltaTime);
    }

    public void UpdateFrame(float fTime)
    {
        if (m_listAniFrames.Count == 0) return;

        m_fTime += fTime;

        float fAniTime = 1.0f / m_nAniFPS;
       
        if (m_fTime > fAniTime)
            m_fTime = 0;
        else
            return;

        SAniFrame sAniStatus = m_listAniFrames[m_nCurStatus];

        if (m_nCurFrame <= sAniStatus.nEnd)
        {
            SetFrame(m_nCurFrame);
            m_nCurFrame++;
        }
        else
            m_nCurFrame = sAniStatus.nStart;        
    }

    public void LoadLocal()
    {
        int counter = 0;
        string line;

        System.IO.StreamReader file = new System.IO.StreamReader(@"c:\test.txt");
        while ((line = file.ReadLine()) != null)
        {
            Debug.Log(line);
            counter++;
        }

        file.Close();

        // Suspend the screen.  
        System.Console.ReadLine();
    }

    public void LoadInfo(string name)
    {
        if (name != "")
        {
            //Resources폴더안에 파일을 읽는다.
            TextAsset textAsset = Resources.Load("AniStatus/" + name) as TextAsset;
            string text = textAsset.text;
            char[] split = { '\n' };
            string[] strSplit = text.Split(split);

            for (int i = 1; i < strSplit.Length-1; i++)
            {
                Debug.Log(strSplit[i]);
                split[0] = ',';
                string[] strSplitFrame = strSplit[i].Split(split);
                int nStart = int.Parse(strSplitFrame[1]);
                int nEnd = int.Parse(strSplitFrame[2]);
                m_listAniFrames.Add(new SAniFrame(nStart, nEnd));
                Debug.Log("AniStatus"+ strSplitFrame[0] + ":" + nStart + "," + nEnd);
            }
        }
        else
        {
            //파일이름을 입력받지못한경우 처음부터 끝까지 하나의 상태로 저장한다.
            int nEnd = m_listAnimation.Count - 1;
            Debug.Log("AniStatusDefaut: 0," + nEnd);
            m_listAniFrames.Add(new SAniFrame(0, nEnd));
        }
    }

    private void OnGUI()
    {
        //if (GUI.Button(new Rect(0, 0, 200, 50), "AniTest:" + m_nCurStatus))
        //{
        //    m_nCurStatus++;
        //}
    }

    public void SetFrame(int idx)
    {
        if (m_listAniFrames.Count == 0) return;
        m_cSpriteRender.sprite = m_listAnimation[idx];
    }

    public void SetStatus(int status)
    {
        if (m_nCurStatus == status) return;
        m_nCurFrame = m_listAniFrames[status].nStart;
        SetFrame(m_nCurFrame);
        m_nCurStatus = status;
        //Debug.Log(m_listAniFrames[status]);
    }
}
