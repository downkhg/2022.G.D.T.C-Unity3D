﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapPathManager : MonoBehaviour
{
    public List<GameObject> m_prefapMapPaths = new List<GameObject>();
    public GameObject[] m_arrayCurMaps;
    public float m_fMapSpeed = 1;
    Queue<GameObject> m_queueCurMaps = new Queue<GameObject>(); //맵을 생성 관리
    public float m_fMapX; //맵의 위치를 저장
    public float m_fCurMapX = 0;


    public void AddMap(int idx)
    {
        m_fCurMapX += m_fMapX;

        GameObject objMapPath = Instantiate(m_prefapMapPaths[idx]);
        objMapPath.transform.SetParent(this.gameObject.transform);
        objMapPath.transform.localPosition = new Vector3(m_fCurMapX, 0, 0);
        objMapPath.transform.localScale = new Vector3(1, 1, 1);
        Debug.Log(this + ".AddMap(" + objMapPath.name + ")");
        m_queueCurMaps.Enqueue(objMapPath);
    }

    public void DeleteMap()
    {
        GameObject objMapPath = m_queueCurMaps.Dequeue();
        Debug.Log(this + ".DeleteMap(" + objMapPath.name + ")");
        Destroy(objMapPath);
    }

    public void MoveMaps()
    {
        this.transform.Translate(new Vector3(m_fMapSpeed * Time.deltaTime * -1, 0, 0));
    }

    //private void OnGUI()
    //{
    //    if (GUI.Button(new Rect(0, 0, 100, 20), "MapAdd"))
    //    {
    //        AddMap(0);
    //    }
    //    if (GUI.Button(new Rect(100, 0, 100, 20), "MapDel"))
    //    {
    //        DeleteMap();
    //    }
    //}

    private void Awake()
    {
        int nCurMapSize = m_arrayCurMaps.Length;
        //두번째 영역의 x위치를 가져온다.
        m_fMapX = m_arrayCurMaps[1].transform.localPosition.x;
        m_fCurMapX = m_fMapX;

        for (int i = 0; i < m_arrayCurMaps.Length; i++)
            m_queueCurMaps.Enqueue(m_arrayCurMaps[i]);

        //AddMap(1);
    }
}