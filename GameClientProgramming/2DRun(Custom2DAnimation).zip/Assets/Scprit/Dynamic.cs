﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dynamic : MonoBehaviour {
    public float m_fSpeed = 10;
    public float m_fJump = 200;
   
    bool m_bSite = false;
    bool m_bDown = false;
   
    Collider2D m_colHead;
    Collider2D m_colBody;

    SpriteRenderer m_cSpriteRanderer;
    AnimateSprite m_cAniSprite;
    Rigidbody2D m_cRigdBody;

    enum eANISTATS { FLY, HIT, IDLE }

// Use this for initialization
    private void Awake() { 
    //void Start () {
        m_cSpriteRanderer = this.gameObject.GetComponent<SpriteRenderer>();
        m_cAniSprite = this.gameObject.GetComponent<AnimateSprite>();
        m_cRigdBody = this.gameObject.GetComponent<Rigidbody2D>();

        Collider2D[] colliders = GetComponents<Collider2D>();

        for(int i = 0; i<colliders.Length; i++)
        {
            if (colliders[i].isTrigger == true)
                m_colHead = colliders[i];
            else
                m_colBody = colliders[i];
        }

        //해당기능의 초기화가 start에서 일어나는 경우 순서가 명확하지않으므로 초기화 전에 접근이 일어날수도있다.
        //그러므로 다음과 같이 직접적으로 호출하여 사용하는것이 안정적이다.
        m_cAniSprite.Initialize(); 
        //Awake에서 처리하더라도 다음과 같은 처리는 순서를 보장할수없으므로 추천하지않는다.
        m_cAniSprite.SetStatus((int)eANISTATS.IDLE);
        Debug.Log(this +".Awake()");
	}
	
	//Update is called once per frame
	void Update () {
        if (!m_cAniSprite) return; //만일의 사태에 대비하는것도 괜찮은 방법. 

        float fTime = Time.deltaTime;
        Vector3 vMove = new Vector3();

        if (Input.GetKeyDown(KeyCode.Space))
        {
            //vMove.y = m_fSpeed * fTime;
            if (!m_bSite)
            {
                m_cRigdBody.AddForce(new Vector3(0, m_fJump, 0));
            }
            else
            {
                m_cRigdBody.AddForce(new Vector3(0, -m_fJump, 0));
                m_bDown = true;
                //머리의 트리거가 활성화되어있으면 박스가 부서지므로,
                //박스를 사용할수 없는 상태로 전환시킨다.
                m_colHead.enabled = false; 
            }
        }

        if(Input.GetKeyDown(KeyCode.DownArrow))
        {
            m_bSite = true;
            m_cAniSprite.SetStatus((int)eANISTATS.HIT);
        }
        if (Input.GetKeyUp(KeyCode.DownArrow))
        {
            m_bSite = false;
            m_cAniSprite.SetStatus((int)eANISTATS.IDLE);
        }

        //if (Input.GetKeyDown(KeyCode.UpArrow))
        //{
        //    vMove.y = m_fSpeed * fTime;
        //}
        //if (Input.GetKey(KeyCode.DownArrow))
        //{
        //    vMove.y = -m_fSpeed * fTime;
        //}
        if (Input.GetKey(KeyCode.RightArrow))
        {
            vMove.x = m_fSpeed * fTime;
            m_cSpriteRanderer.flipX = false;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            vMove.x = -m_fSpeed * fTime;
            m_cSpriteRanderer.flipX = true;
        }

        this.gameObject.transform.Translate(vMove);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //오브젝트의 이름만으로는 이름이 같을때만 삭제가능하므로, tag기능을 이용하여 분류한다.
        if (collision.gameObject.tag == "Box")
        {
            Destroy(collision.gameObject);
            GameManager.GetInstance().AddScore(1);
        }
        //머리(트리거)닿으면 상자를 트리거로 만들어 통과시킨다.
        else if (collision.gameObject.tag == "Bottom")
            m_colBody.isTrigger = true;

        //Debug.Log(this+ ".OnTriggerEnter2D("+collision.gameObject.name+")");
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        //Debug.Log(this + ".OnTriggerStay2D(" + collision.gameObject.name + ")");
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        //해당오브젝트를 벗어날때 다시 트리거를 해제시킨다.
        if (collision.gameObject.tag == "Bottom" || collision.gameObject.tag == "Box")
        {
            m_colBody.isTrigger = false;
            m_bDown = false;
            m_colHead.enabled = true; //머리에 트리거를 사용가능상태로 만든다.
        }

        //Debug.Log(this + ".OnTriggerExit2D(" + collision.gameObject.name + ")");
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        m_cAniSprite.SetStatus((int)eANISTATS.IDLE);

        //Debug.Log(this + ".OnCollisionEnter2D(" + collision.gameObject.name + ")");
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Bottom" || collision.gameObject.tag == "Box")
            if(m_bDown)
                m_colBody.isTrigger = true;

        //Debug.Log(this + ".OnCollisionStay2D(" + collision.gameObject.name + ")");
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        m_cAniSprite.SetStatus((int)eANISTATS.FLY);

        //Debug.Log(this + ".OnCollisionExit2D(" + collision.gameObject.name + ")");
    }
}
