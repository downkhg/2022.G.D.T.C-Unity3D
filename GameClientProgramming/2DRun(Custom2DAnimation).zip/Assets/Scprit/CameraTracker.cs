﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTracker : MonoBehaviour {
    public GameObject m_Targer;
    public float m_fSpeed;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //Vector3 vTargetPos = m_Targer.transform.position;
        //Vector3 vPos = this.gameObject.transform.position;

        //Vector3 vTransPos = 
        //    Vector3.Lerp(vPos, vTargetPos, m_fSpeed * Time.deltaTime);
        //vTransPos.z = vPos.z;

        //this.gameObject.transform.position = vTransPos;
        //    new Vector3(vPos.x, vPos.y, gameObject.transform.position.z);
        //this.gameObject.transform.Rotate(0, 0, 1);
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    Debug.Log(this + ".OnTriggerEnter2D:" + collision.gameObject.name);
    //}

    private void OnTriggerExit2D(Collider2D collision)
    {
        //여기에 맵을 추가 삭제 코드를 사용한다.
        if(collision.gameObject.tag == "MapPath")
        {
            GameManager.GetInstance().MapPathManagement();
        }

        Debug.Log(this+ ".OnTriggerExit2D:"+ collision.gameObject.name);
    }
}
