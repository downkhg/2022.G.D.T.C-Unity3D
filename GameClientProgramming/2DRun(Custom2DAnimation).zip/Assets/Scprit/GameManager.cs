﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ranking
{
    delegate int ComparerFuc(Ranking A, Ranking B);

    string m_strName;
    int m_nScore;

    //생성자
    public Ranking(string name, int score)
    {
        m_strName = name;
        m_nScore = score;
    }

    //Setter,Getter
    public string Name
    {
        get { return m_strName; }
        set { m_strName = value; }
    }

    public int Score
    {
        get { return m_nScore; }
        set { m_nScore = value; }
    }
}

public class GameManager : MonoBehaviour {
    public Dynamic m_cPlayer;
    GameObject m_MapPathManager;
    MapPathManager m_cMapPathManager;

    public GameObject m_perfapRankData; //등록할 버튼의 프리팹
    public RectTransform m_rectRankContent;
    List<GameObject> m_listLankDatas = new List<GameObject>(); //버튼을 관리하기위한 오브젝트 풀

    public Text m_textTime;
    public Text m_textScore;

    public InputField m_inputFieldName;

    //GUI관리용
    public List<GameObject> m_listGUIStatus; //UI장면 관리 리스트
    eGUIStatus m_eStatus = 0;
    public enum eGUIStatus { TITILE, PLAY, INPUT_NAME, RANKING, GAMEOVER }

    int m_nGameScore = 0; //점수
    float m_fGameTime = -1; //게임 시작후 흐른시간. //-1 : 시간이 흐르지않음.

    //리스트는 사용전에 반드시 인스턴스화 해야한다.
    List<Ranking> m_listLankings = new List<Ranking>();

    //싱글톤을 이용하여 어디서든지 쉽게 게임매니저에 접근가능하도록함.
    static GameManager m_cInstance;

    public static GameManager GetInstance()
    {
        return m_cInstance;
    }

    public void AddScore(int score)
    {
        m_nGameScore += score;
    }

    public void ResetScore()
    {
        m_nGameScore = 0;
    }

    //스코어는 외부에서 함부로 수정되지않도록 함수를 통해서만 제어하도록만든다.
    public int GetScore() 
    {
        return m_nGameScore;
    }

    public float GetCurTime()
    {
        return m_fGameTime;
    }
    //시간이 흐르게 초기값을 지정
    public void InitTime()
    {
        m_fGameTime = 0;
    }
    //시간을 더이상 확인하지않도록 변경
    public void ResetTime()
    {
        m_fGameTime = -1;
    }

    public List<Ranking> GetRankings()
    {
        return m_listLankings;
    }

    public void SetRankingData(Ranking ranking)
    {
        //게임오브젝트의 동적생성
        GameObject objRankData = Instantiate(m_perfapRankData) as GameObject;
        GUIRankData cGUIRankData = objRankData.GetComponent<GUIRankData>();
        cGUIRankData.Set("", ranking.Name, ranking.Score);
        objRankData.transform.SetParent(m_rectRankContent.gameObject.transform);
        objRankData.transform.localScale = new Vector3(1, 1, 1);
        objRankData.transform.localPosition = new Vector3(0, 0, 0);
        //생성된 객체를 오브젝트풀에서 추가
        m_listLankDatas.Add(objRankData);
    }
    public void DeleteRankingData(int idx)
    {
        Destroy(m_listLankDatas[idx]);
    }
    public void SetStatus(eGUIStatus status)
    {
        //GUI에서 해야할 사전 작업들을 추가한다.
        GameManager.GetInstance().EventPauseGame(true);
        switch (status)
        {
            case eGUIStatus.TITILE:
                GameManager.GetInstance().ResetScore();
                break;
            case eGUIStatus.PLAY:
                GameManager.GetInstance().EventPauseGame(false);
                GameManager.GetInstance().InitTime();
                break;
            case eGUIStatus.INPUT_NAME:

                break;
            case eGUIStatus.RANKING:
                //게임매니저에 등록되어있는 랭킹정보를 가져와 GUIRanking을 갱신한다.
                List<Ranking> listRanking = GameManager.GetInstance().GetRankings();
                DeleteRankingDatas(); //기존에 버튼들을 모두 삭제하고 새로 추가한다.
                for (int i = 0; i < listRanking.Count; i++)
                    SetRankingData(listRanking[i]);
                ResizeContent();
                break;
            case eGUIStatus.GAMEOVER:

                break;
        }

        //세팅된 UI만 보여주도록만듦
        for (int i = 0; i < m_listGUIStatus.Count; i++)
        {
            if (i == (int)status)
                m_listGUIStatus[i].SetActive(true);
            else
                m_listGUIStatus[i].SetActive(false);
        }

        m_eStatus = status;
    }
    public void UpdateStatus()
    {
        //현재 씬에서 셋팅된 업데이트를 호출한다.
        int nStatus = (int)m_eStatus;
        switch (m_eStatus)
        {
            case eGUIStatus.TITILE:

                break;
            case eGUIStatus.PLAY:
                float maxtime = 30;
                float time = GameManager.GetInstance().GetCurTime();
                //하지만, 다형성이 없다면 다음과 같이 필요할때마다 타입에 맞게 가져와야한다.
                //GUIPlay cGUIPlay = m_listGUIStatus[nStatus].GetComponent<GUIPlay>();
                SetTime(time, maxtime);
                SetScore(GameManager.GetInstance().GetScore());
                if (time > maxtime)
                {
                    bool bCheck = false;
                    //기존에 랭킹리스트에서 현제 점수보다 높은 값이 있는지 확인한다.
                    //랭킹리스트, 현재점수
                    //만약 랭킹에 기록이 없으면,
                    //랭킹안에 들었다 -> 랭킹리스트를 하나씩 비교해 그보다 큰점수가 있다.

                    //기록을 입력받는다.
                    List<Ranking> listRankings = GameManager.GetInstance().GetRankings();
                    int nScore = GameManager.GetInstance().GetScore();

                    if (listRankings.Count < 3)
                    {
                        bCheck = true;
                    }
                    else
                    {
                        for (int i = 0; i < listRankings.Count; i++)
                        {
                            if (listRankings[i].Score < nScore)
                                bCheck = true;
                        }
                    }

                    if (bCheck)
                        SetStatus(eGUIStatus.INPUT_NAME);
                    else
                        SetStatus(eGUIStatus.RANKING);
                }
                break;
            case eGUIStatus.INPUT_NAME:

                break;
            case eGUIStatus.RANKING:

                break;
            case eGUIStatus.GAMEOVER:

                break;
        }
    }
    public void DeleteRankingDatas()
    {
        for (int i = 0; i < m_listLankDatas.Count; i++)
            Destroy(m_listLankDatas[i]);
        m_listLankDatas.Clear();
    }
    public void ResizeContent()
    {
        GridLayoutGroup rayOut = m_rectRankContent.gameObject.GetComponent<GridLayoutGroup>();
        float fContentH = rayOut.cellSize.y * m_listLankDatas.Count;
        m_rectRankContent.sizeDelta = new Vector2(m_rectRankContent.sizeDelta.x, fContentH);
    }//컨텐츠의 영역높이를 데이터수만큼 늘려준다.

    public void SetTime(float time, float max_time)
    {
        //남은 플레이시간 표시(들오는 값은 초단위)
        float fTime = max_time - time;
        int nMin = (int)fTime / 60;
        int nSec = (int)fTime % 60;
        string strTime = string.Format("{0:00}:{1:00}", nMin, nSec);
        m_textTime.text = strTime;
    }
    public void SetScore(int score)
    {
        m_textScore.text = string.Format("{0}", score);
    }

    public string GetInputName()
    {
        return m_inputFieldName.text;
    }

    private void Awake()
    {
        //등록된 오브젝트로 부터 필요한 클래스를 받아온다.
        m_cInstance = this; //싱글톤 등록
        //게임관리자를 통해서 변경하는것이 가장이상적이다.
        SetStatus(eGUIStatus.TITILE);
    }

    // Use this for initialization
    void Start () {
        m_listLankings.Add(new Ranking("usj", 10000));
        m_listLankings.Add(new Ranking("kmg", 100000));
        m_listLankings.Sort(
            delegate(Ranking A, Ranking B) 
            {
                if (A.Score > B.Score) return -1;
                else if (A.Score < B.Score) return 1;
                return 0;
            } );
        //m_listLankings.Sort(()=>Ranking.Comparer);
    }

    private void OnGUI()
    {
        for(int i = 0; i<m_listLankings.Count; i++)
        {
            string log = m_listLankings[i].Name + "," + m_listLankings[i].Score;
            GUI.Box(new Rect(0,0+20*i,100,20),log);
        }
    }

    // Update is called once per frame
    void Update () {
        if (m_fGameTime >= 0)
        {
            m_fGameTime += Time.deltaTime;

            
            //m_cGUIManager.GetGUIObject(GUIManager.eGUIStatus.PLAY).SetTime(m_fGameTime, 180);
        }

        UpdateStatus();
        if(m_cMapPathManager) m_cMapPathManager.MoveMaps(); //맵을 이동시킨다.


        //m_cGUIManager.GetGUIObject(GUIManager.eGUIStatus.PLAY).SetScore(m_nGameScore);
    }

    public void OnClickTitleStart()
    {
        OnLoadMapPathManager();
        SetStatus(eGUIStatus.PLAY);
    }

    public void OnClickRetry()
    {
        SetStatus(eGUIStatus.TITILE);
    }

    public void OnClickExit()
    {
        Application.Quit();
    }

    public void OnEndEventInputName()
    {
        //기록한 이름과 현재 점수를 리스트에 추가한다.
        //최고점수부터 보여준다.
        string name = GetInputName();
        m_listLankings.Add(new Ranking(name, m_nGameScore));
        m_listLankings.Sort(
           delegate (Ranking A, Ranking B)
           {
               if (A.Score > B.Score) return -1;
               else if (A.Score < B.Score) return 1;
               return 0;
           });

        if (m_listLankings.Count > 3)
            m_listLankings.Remove(m_listLankings[3]);


        SetStatus(eGUIStatus.RANKING);
    }

    public void MapPathManagement() //맵을 추가하고 이전 맵을 삭제하는 동작을 한다.
    {
        m_cMapPathManager.AddMap(0);
        m_cMapPathManager.DeleteMap();
    }

    public void EventPauseGame(bool bPause)
    {
        if (bPause)
            Time.timeScale = 0;
        else
            Time.timeScale = 1;
    }

    public void OnLoadMapPathManager()
    {
        if (m_MapPathManager)
            Destroy(m_MapPathManager);

        m_MapPathManager = Instantiate(Resources.Load("Prefaps/MapPathManager") as GameObject);
        m_MapPathManager.transform.localPosition = new Vector3(0, 0, 0);
        m_MapPathManager.transform.localScale = new Vector3(1, 1, 1);
        m_cMapPathManager = m_MapPathManager.GetComponent<MapPathManager>();
    }
}
