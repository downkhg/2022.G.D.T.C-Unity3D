using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PluginManager : MonoBehaviour
{
#if UNITY_ANDROID
    AndroidJavaObject m_AndroidJavaObject;
    AndroidJavaObject m_ActivityInstance;
#else
#endif
    int nNavitiveData;

    int GetInt()
    {
        int nResult = -1;
#if UNITY_ANDROID
        if(m_AndroidJavaObject != null)
            nResult = m_AndroidJavaObject.Call<int>("GetInt");
#else
#endif
        return nResult;
    }

    void ShowToastMsg(string msg, int time)
    {
#if UNITY_ANDROID
        if (m_AndroidJavaObject != null)
        {
            m_AndroidJavaObject.Call("ToastMsg", m_ActivityInstance, msg, time);
        }
        else
        {
            Debug.LogError("PluginManager.AndroidJavaObejct is null - ShowToastMsg!");
        }
#else
#endif
    }

    // Start is called before the first frame update
    void Start()
    {
#if UNITY_ANDROID
        using (AndroidJavaObject unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            m_ActivityInstance = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
            //m_ActivityInstance = uintyPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
        }

        m_AndroidJavaObject = new AndroidJavaObject("com.sbsgame.android.unityandroidplugin.Plugin");
        if (m_AndroidJavaObject != null)
            Debug.LogWarning("PluginManager.AndroidJavaObejct:" + m_AndroidJavaObject);
        else
            Debug.LogError("PluginManager.AndroidJavaObejct is null!");
#else
#endif
    }

    void OnGUI()
    {
        nNavitiveData = GetInt();

        if (m_AndroidJavaObject != null)
        {
            GUI.Box(new Rect(0, 0, 200, 20), "GetInt:" + nNavitiveData);
            if(GUI.Button(new Rect(0, 20, 200, 20), "ShowToast:" + nNavitiveData))
            {
                ShowToastMsg("test", 1);
            }
        }
        else
        {
            GUI.Box(new Rect(0, 0, 200, 20), "Plugin Load Failed!");
            GUI.Box(new Rect(0, 20, 200, 20), "Plugin Load Failed!");
        }

    }
}
